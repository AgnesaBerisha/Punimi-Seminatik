public class Leter {

    private final int vlera;
    private final int lloji;

    public Leter(int vlera, int lloji) {
        this.vlera = vlera;
        this.lloji = lloji;
    }

    public int ktheVleren() {
        return vlera;
    }

    public String vleraSiString() {
        String vleraSiString = "";
        if (vlera > 1 && vlera < 11) {
            vleraSiString = "" + vlera;
        } else {
            switch (vlera) {
                case 1:
                    vleraSiString = "Pik";
                    break;
                case 11:
                    vleraSiString = "Xhandar";
                    break;
                case 12:
                    vleraSiString = "Mbretereshe";
                    break;
                case 13:
                    vleraSiString = "Mbreti";
                    break;
                default:
                    break;
            }
        }
        return vleraSiString;
    }

    public String llojiSiString() {
        String llojiSiString = "";
        switch (lloji) {
            case 1:
                llojiSiString = "Zemer";
                break;
            case 2:
                llojiSiString = "Diamant";
                break;
            case 3:
                llojiSiString = "Gjethe";
                break;
            case 4:
                llojiSiString = "Spath";
                break;
            default:
                break;
        }

        return llojiSiString;
    }

    @Override
    public String toString() {
        return vleraSiString()+" "+llojiSiString();
    }
}
