public abstract class Lojtari implements ILojtari {

    protected String emri;
    protected Leter[] doraMeLetra;
    protected int indeksiLetresArdhshme;

    public Lojtari(String emri) {
        this.emri = emri;
        doraMeLetra = new Leter[2];
    }

    @Override
    public boolean eshteMeEVogel(Leter letra1, Leter letra2) {
        return letra1.ktheVleren() > letra2.ktheVleren();
    }

    @Override
    public abstract void prano(Leter eArdhshme);

    @Override
    public void shfaqLetrat() {
        System.out.println(emri + ": " + doraMeLetra[0] + "," + doraMeLetra[1]+". Total pike: "+vleraELetrave());
    }

    @Override
    public int vleraELetrave() {
        int shuma = 0;
        for (Leter letra : doraMeLetra) {
            shuma += letra.ktheVleren();
        }
        return shuma;
    }

}
