public interface ILojtari {

    boolean eshteMeEVogel(Leter letra1, Leter letra2);

    void prano(Leter eArdhshme);

    void shfaqLetrat();

    int vleraELetrave();
    
}
