
public class Shperndaresi {

    private Leter[] pako;
    private int letraShfrytezuar;
    private int indeksiLetraArdhshme;

    public Shperndaresi() {
        pako = new Leter[52];
        int indeksi = 0;
        for (int lloji = 1; lloji <= 4; lloji++) {
            for (int vlera = 1; vlera <= 13; vlera++) {
                pako[indeksi] = new Leter(vlera, lloji);
                indeksi++;
            }
        }
    }

    public void perziej() {
        for (int i = 0; i < pako.length; i++) {
            Leter temp = pako[i];
            int indeksIRastesishem = (int)(Math.random()*(i+1));
            pako[i] = pako[indeksIRastesishem];
            pako[indeksIRastesishem] = temp;
        }
    }

    public void ndajLeter(ILojtari lojtari) {
        Leter leter = letraArdhshme();
        lojtari.prano(leter);
        letraShfrytezuar++;
    }

    private Leter letraArdhshme() {
        Leter letraTjeter = ktheLetren(indeksiLetraArdhshme);
        indeksiLetraArdhshme++;
        return letraTjeter;
    }

    public Leter ktheLetren(int indeksi) {
        return pako[indeksi];
    }

    public boolean kaEndeLetra() {
        return letraShfrytezuar < numriLetrave();
    }

    public int numriLetrave() {
        return pako.length;
    }

}
