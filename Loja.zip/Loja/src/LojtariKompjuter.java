public class LojtariKompjuter extends Lojtari {

    protected int indeksiILetresMinimale;

    public LojtariKompjuter(String emri) {
        super(emri);
    }

    @Override
    public void prano(Leter eArdhshme) {
        switch (indeksiLetresArdhshme) {
            case 0: {
                doraMeLetra[indeksiLetresArdhshme] = eArdhshme;
                indeksiLetresArdhshme++;
                break;
            }
            case 1: {
                System.out.println("====================================");
                doraMeLetra[indeksiLetresArdhshme] = eArdhshme;
                ndryshoIndeksinMinimal();
                indeksiLetresArdhshme++;
                System.out.println(emri + " mbane 0:'" + doraMeLetra[0] + "' dhe 1:'" + doraMeLetra[1] + "'.");

                break;
            }
            default: {
                System.out.println("====================================");
                ndryshoIndeksinMinimal();
                int indeksiLetresSeHedhur = gjejLetrenQeHudhet();

                System.out.println(emri + " hodhi " + doraMeLetra[indeksiLetresSeHedhur]);
                //letra me e vogel se 6 u hudh, vendose aty te ardhshmen
                doraMeLetra[indeksiLetresSeHedhur] = eArdhshme;

                System.out.println(emri + " mbane 0:'" + doraMeLetra[0] + "' dhe 1:'" + doraMeLetra[1] + "'.");

                break;
            }
        }
    }

    public void ndryshoIndeksinMinimal() {
        if (doraMeLetra[0].ktheVleren() < doraMeLetra[1].ktheVleren()) {
            indeksiILetresMinimale = 0;
        } else {
            indeksiILetresMinimale = 1;
        }
    }

    private int gjejLetrenQeHudhet() {
        int indeksiILetresQeHudhet;
        indeksiILetresQeHudhet = -1;

        if (doraMeLetra[indeksiILetresMinimale].ktheVleren() < 6) {
            indeksiILetresQeHudhet = indeksiILetresMinimale;
        } else if (doraMeLetra[0].ktheVleren() < doraMeLetra[1].ktheVleren()) {
            indeksiILetresQeHudhet = 0;
        } else {
            indeksiILetresQeHudhet = 1;
        }
        return indeksiILetresQeHudhet;
    }
}
