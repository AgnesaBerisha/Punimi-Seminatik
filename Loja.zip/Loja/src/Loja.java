
import java.util.Scanner;

public class Loja {
    private final ILojtari[] lojtaret;
    private final Shperndaresi shperndaresi;

    public Loja(ILojtari[] lojtaret) {
        this.lojtaret = lojtaret;
        shperndaresi = new Shperndaresi();
        shperndaresi.perziej();
    }

    public void fillo() {
        //fillimisht ndaj dy letra per cdo lojtar
        for (ILojtari lojtaret1 : lojtaret) {
            shperndaresi.ndajLeter(lojtaret1);
            shperndaresi.ndajLeter(lojtaret1);
        }
        while (shperndaresi.kaEndeLetra()) {
            for (ILojtari lojtaret1 : lojtaret) {
                shperndaresi.ndajLeter(lojtaret1);
            }
        }

        for (ILojtari lojtaret1 : lojtaret) {
            lojtaret1.shfaqLetrat();
        }
    }

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        String emriLojtari1;
        String emriLojtari2;
        Scanner sc = new Scanner(System.in);
        System.out.println("===========================================");
        System.out.println("Filloi loja NJERI vs. Kompjuteri");
        do {
            System.out.println("Lojtar shenoni emrin tuaj:");
            emriLojtari1 = sc.nextLine();
        } while (emriLojtari1.equals(""));
        ILojtari[] lojtaret = {new LojtariNjeri(emriLojtari1), new LojtariKompjuter("Pentium")};
        Loja loja = new Loja(lojtaret);
        loja.fillo();
        System.out.println("*********************************************************");
        System.out.println("Filoi loja Njeri vs. Njeri");
        do {
            System.out.println("Lojtari i pare shenoni emrin tuaj:");
            emriLojtari1 = sc.nextLine();
        } while (emriLojtari1.equals(""));
        do {
            System.out.println("Lojtari i dyte shenoni emrin tuaj:");
            emriLojtari2 = sc.nextLine();
        } while (emriLojtari2.equals(""));
        
        ILojtari[] lojtarett = {new LojtariNjeri1(emriLojtari1),new LojtariNjeri2(emriLojtari2)};
        Loja lojaa;
        lojaa = new Loja(lojtarett);
        loja.fillo();
        System.out.println("----------------------------------------------------------");
        System.out.println("Shtyp ENTER per te filluar lojen tjeter");
        sc.nextLine();
        System.out.println("==========================================================");
        System.out.println("Filloi loja Kompjuter vs. Kompjuter");
        lojtaret[0] = new LojtariKompjuter("Pentium X");
        loja = new Loja(lojtaret);
        loja.fillo();
    }
}
