
import java.util.Scanner;

  
public class LojtariNjeri2 extends Lojtari {

    public LojtariNjeri2(String emri2) {
        super(emri2);
    }

  
    @Override
    public void prano(Leter eArdhshme) {
        if (indeksiLetresArdhshme == 0 || indeksiLetresArdhshme == 1) {
            doraMeLetra[indeksiLetresArdhshme] = eArdhshme;
            indeksiLetresArdhshme++;
        } else {
            System.out.println("====================================");
            System.out.println(emri + " ju keni 0:'" + doraMeLetra[0] + "' dhe 1:'" + doraMeLetra[1] + "'.");
            System.out.print("Cilen do e hidhni 0 apo 1:");

            Scanner sc = new Scanner(System.in);
            boolean hyrjeValide = false;
            int hyrja = -1;
            do {
                hyrja = new Integer(sc.nextLine());
                if (hyrja == 0 || hyrja == 1) {
                    hyrjeValide = true;
                }
            } while (!hyrjeValide);
            doraMeLetra[hyrja] = eArdhshme;
        }}}
    